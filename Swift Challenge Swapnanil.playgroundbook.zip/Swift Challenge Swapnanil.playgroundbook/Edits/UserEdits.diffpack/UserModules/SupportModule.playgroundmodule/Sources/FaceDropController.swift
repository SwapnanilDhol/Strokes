import UIKit
import ARKit

public class FaceDropController: UIViewController {
    
    //MARK: Instances of Cocoa
    
    let scene = ARSCNView()
    let introductoryLabel = UILabel()
    let notificationView = UIView()
    let messageLabel = UILabel()
    var timer: Timer?
    var labelTimer: Timer?
    var didDetectFace = false
    var didSmile = false 
    var resultList = [String]()
    var (left,right,normal) = (0,0,0)
    
    let timeLabel: UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.text = "5"
        lb.alpha = 0.8
        lb.numberOfLines = 1
        lb.textColor = .white
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 230)
        return lb
    }()
    
    var notificationViewCenterYAnchor: NSLayoutConstraint!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setupNotificationView()
        addARView()
        scene.delegate = self
        
        guard ARFaceTrackingConfiguration.isSupported else {return}
        
        
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        let config = ARFaceTrackingConfiguration()
        scene.preferredFramesPerSecond = 30
        scene.rendersContinuously = false
        scene.session.run(config)
        self.view.backgroundColor = .systemGray
        notificationViewAnimation()
        
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
    }
    
    
    private func addARView()
    {
        self.view.addSubview(scene)
        scene.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            
            scene.topAnchor.constraint(equalTo: self.view.topAnchor),
            scene.bottomAnchor.constraint(equalTo: self.view.bottomAnchor),
            scene.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            scene.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        ])
        
        self.view.sendSubviewToBack(scene)
    }
    
    private func initialAnimations() {
        
    }
    
    //MARK: View Constraints
    
    private func setIntroductoryLabelConstraints() {
        self.view.addSubview(introductoryLabel)
        introductoryLabel.translatesAutoresizingMaskIntoConstraints = false
        introductoryLabel.numberOfLines = 0
        introductoryLabel.font = UIFont(name: "Helvetica", size: 18)
        introductoryLabel.textColor = .label
        NSLayoutConstraint.activate([
            introductoryLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            introductoryLabel.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        ])
        
    }
    
    private func setupNotificationView() {
        
        self.view.addSubview(notificationView)
        notificationView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            
            notificationView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 50),
            notificationView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -50),
            notificationView.heightAnchor.constraint(equalToConstant: 70),
            notificationView.widthAnchor.constraint(equalToConstant: 100)
            
        ])
        notificationViewCenterYAnchor = notificationView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: -80)
        notificationViewCenterYAnchor.isActive = true
        notificationView.layer.cornerRadius = 20
        notificationView.alpha = 1.0
        notificationView.backgroundColor = .white
        shadowToView(view: notificationView)
        
    }
    
    private func setupMessageLabel() {
        
        view.addSubview(messageLabel)
        view.addSubview(timeLabel)
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            messageLabel.leadingAnchor.constraint(equalTo: notificationView.leadingAnchor, constant: 5),
            messageLabel.trailingAnchor.constraint(equalTo: notificationView.trailingAnchor, constant: -5),
            messageLabel.topAnchor.constraint(equalTo: notificationView.topAnchor, constant: 5),
            messageLabel.bottomAnchor.constraint(equalTo: notificationView.bottomAnchor, constant: -5),
            timeLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            timeLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
        
        
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.numberOfLines = 0
        messageLabel.text = "No Face Detected"
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        messageLabel.textColor = .black

        
    }
    
    func shadowToView(view : UIView){
        view.layer.shadowOffset = CGSize(width: 0, height: 3)
        view.layer.shadowOpacity = 0.6
        view.layer.shadowRadius = 3.0
        view.layer.shadowColor = UIColor.darkGray.cgColor
    }
    
    private func setupTimerAndLabel() {
        
        labelTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateLabel), userInfo: nil, repeats: true)
    }
    
    private func notificationViewAnimation() {
        
        notificationViewCenterYAnchor.constant = 10
        UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 0.6,initialSpringVelocity: 4,options: .curveEaseOut, animations: {
            self.view.layoutIfNeeded()
        }) { (_) in
            self.view.bringSubviewToFront(self.notificationView)
            self.setupMessageLabel()
        }
        
    }
    //MARK: Logic
    
    
    
    private func displayAnalysisController(with message: String, didDetectStroke: Bool) {
        
        let vc = AnalysisViewController()
        vc.message = message
        vc.didDetectStroke = didDetectStroke
        vc.modalPresentationStyle = .fullScreen
        vc.delegate = self
        labelTimer?.invalidate()
        
        DispatchQueue.main.async {
            self.present(vc, animated: true)
        }
        
        
    }
    
    @objc private func fiveSeconds() {
        //Analysis of data
        
        if left > normal || right > normal {
            
            //Stroke Detected
            if left > right {
                self.displayAnalysisController(with: "A left side face drop was detected. This might symbolize a stroke in the right half of the brain. Please contact medical facilities ASAP.", didDetectStroke: true)
            }
            else {
                self.displayAnalysisController(with: "A right side face drop was detected. This might symbolize a stroke in the left half of the brain. Please contact medical facilities ASAP.", didDetectStroke: true)
            }
        }
            
        else {
            self.displayAnalysisController(with: "The analysis did not show signs of stroke but if you're feeling uneasy it's best to contact your doctor now.", didDetectStroke: false)
        }
        
        
    }
    
    @objc private func updateLabel() {
        DispatchQueue.main.async {
            var currentTime = Int(self.timeLabel.text!) ?? 0
            if currentTime != 0 {
                currentTime -= 1
                self.timeLabel.text = "\(currentTime)"
            }
            else {
                self.fiveSeconds()
            }
        }
        
        
    }
}

extension FaceDropController: ARSCNViewDelegate
{
    public func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let faceMesh = ARSCNFaceGeometry(device: scene.device!)
        let node = SCNNode(geometry: faceMesh)
        node.geometry?.firstMaterial?.fillMode = .lines
        return node
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        if let faceAnchor = anchor as? ARFaceAnchor, let faceGeometry = node.geometry as? ARSCNFaceGeometry {
            if !didSmile {
                DispatchQueue.main.async {
                    self.messageLabel.text = "Face Detected.\nPlease open your mouth to begin."
                }
            }
            faceGeometry.update(from: faceAnchor.geometry)
            faceDropAnalyzer(anchor: faceAnchor)
        }
        else {
            didDetectFace = false 
            if labelTimer?.isValid ?? false {
                timeLabel.text = "\(5)"
                labelTimer?.invalidate()
            }
            messageLabel.text = "No Face Detected"
        }
    }
    
    private func faceDropAnalyzer(anchor: ARFaceAnchor) {
        
        let bottomLeftJaw = anchor.blendShapes[.jawLeft]
        let bottomRightJaw = anchor.blendShapes[.jawRight]
        
        let dropValueLeft = (bottomLeftJaw?.decimalValue) ?? 0
        let dropValueRight = (bottomRightJaw?.decimalValue) ?? 0
        
        let mouthOpen = anchor.blendShapes[.jawOpen]
        let mouthOpenValue = (mouthOpen?.decimalValue) ?? 0
        
        if mouthOpenValue > 0.1 {
            didSmile = true 
            if !didDetectFace {
                setupTimerAndLabel()
            }
            didDetectFace = true 
            if dropValueRight > 0.1 {
                DispatchQueue.main.async {
                    self.messageLabel.text = "👈🏼 Left side drop detected."
                }
                left += 1
                
            }
            else if dropValueLeft > 0.1 {
                DispatchQueue.main.async {
                    self.messageLabel.text = "👉🏼 Right side drop detected."
                }
                right += 1
            }
        else {
                //User is smiling
                    DispatchQueue.main.async {
                        self.messageLabel.text = "Everything looks normal ✅"
                    
                }
                normal += 1
                
            } 
        }
        else {
            DispatchQueue.main.async {
                self.messageLabel.text = "Open your mouth to begin analysis"
            }
        }
        }
        
        
        
    }

extension FaceDropController: ReRun {
    
    public func initiateReRun() {
        let config = ARFaceTrackingConfiguration()
        scene.preferredFramesPerSecond = 30
        scene.rendersContinuously = false
        scene.session.run(config)
        didDetectFace = false 
        didSmile = false 
        timeLabel.text = "\(5)"
        left = 0
        right = 0
        normal = 0
        messageLabel.text = "Re-Analysis"
    }
    
}
 

