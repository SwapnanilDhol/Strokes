
import UIKit
import ARKit
import RealityKit


public class HandDroppingController: UIViewController, ReRun {
    
    let notificationView = UIView()
    let messageLabel = UILabel()
    var (left, right, normal) = (0,0,0)
    var (leftDrop, rightDrop, bothUp) = (0,0,0)
    var didDetectBody = false
    var didRaiseHand = false
    var labelTimer: Timer?
    let timeLabel: UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.text = "5"
        lb.alpha = 0.8
        lb.numberOfLines = 1
        lb.textColor = .white
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 230)
        return lb
    }()
    var arView = ARView(frame: CGRect(x: 0, y: 0, width: 375, height: 375), cameraMode: .ar, automaticallyConfigureSession: true)
    let configuration = ARBodyTrackingConfiguration()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard ARBodyTrackingConfiguration.isSupported else { return }
        
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setupArView()
    }
    
    
    
    //MARK: Setup Views
    
    private func setupNotificationView() {
        arView.addSubview(notificationView)
        notificationView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            
            notificationView.leadingAnchor.constraint(equalTo: arView.leadingAnchor, constant: 50),
            notificationView.trailingAnchor.constraint(equalTo: arView.trailingAnchor, constant: -50),
            notificationView.topAnchor.constraint(equalTo: arView.topAnchor, constant: 20),
            notificationView.heightAnchor.constraint(equalToConstant: 70),
            notificationView.widthAnchor.constraint(equalToConstant: 100)
        ])
        notificationView.layer.cornerRadius = 20
        notificationView.alpha = 1.0
        notificationView.backgroundColor = .white
        shadowToView(view: notificationView)
        setupMessageLabel()
        
        
        
    }
    private func setupArView() {
        
        arView.session.delegate = self
        arView.session.run(configuration)
        self.view.addSubview(arView)
        
        arView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            
            arView.topAnchor.constraint(equalTo: self.view.topAnchor),
            arView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            arView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            arView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
            
        ])
        //view.sendSubviewToBack(arView)
        
        //setupMessageLabel()
        setupNotificationView()
        
        
        
    }
    
    private func setupMessageLabel() {
        arView.addSubview(messageLabel)
        arView.addSubview(timeLabel)
        timeLabel.translatesAutoresizingMaskIntoConstraints = false 
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            messageLabel.leadingAnchor.constraint(equalTo: notificationView.leadingAnchor, constant: 15),
            messageLabel.trailingAnchor.constraint(equalTo: notificationView.trailingAnchor, constant: -15),
            messageLabel.topAnchor.constraint(equalTo: notificationView.topAnchor, constant: 10),
            messageLabel.bottomAnchor.constraint(equalTo: notificationView.bottomAnchor, constant: -10),
            timeLabel.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
            timeLabel.centerYAnchor.constraint(equalTo: arView.centerYAnchor)
        ])
        
        
        messageLabel.numberOfLines = 0
        messageLabel.text = "Point your camera towards a person to begin analysis"
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        messageLabel.textColor = .black
        //view.bringSubviewToFront(timeLabel)
        
    }
    
    private func shadowToView(view : UIView){
        view.layer.shadowOffset = CGSize(width: 0, height: 3)
        view.layer.shadowOpacity = 0.6
        view.layer.shadowRadius = 3.0
        view.layer.shadowColor = UIColor.darkGray.cgColor
    }
    
    private func setupTimerAndLabel() {
        
        if labelTimer?.isValid ?? false {
            
        }
        else {
            labelTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateLabel), userInfo: nil, repeats: true)
        }
    }
    
    //MARK: Logic
    
    private func displayAnalysisController(with message: String, didDetectStroke: Bool) {
        
        let vc = AnalysisViewController()
        vc.message = message
        vc.didDetectStroke = didDetectStroke
        vc.delegate = self
        vc.modalPresentationStyle = .fullScreen
        labelTimer?.invalidate()
        
        DispatchQueue.main.async {
            self.present(vc, animated: true)
        }
        
        
    }
    
    @objc private func fiveSeconds() {
        //Analysis of data
        
        if left > normal {
            self.displayAnalysisController(with: "There was a significant drop in the left arm.\nChances of stroke is high.\nPlease contact medical facilities ASAP", didDetectStroke: true)
        }
        
        if right > normal {
            self.displayAnalysisController(with: "There was a significant drop in the right arm.\nChances of stroke is high.\nPlease contact medical facilities ASAP", didDetectStroke: true)
        }
        
        if normal > right && normal > left {
            
            self.displayAnalysisController(with: "Chances of stroke is less.\nHowever, if you feel uneasy, it is best to contact medical facilities ASAP", didDetectStroke: false)
        }
        
        
        
    }
    
    @objc private func updateLabel() {
        DispatchQueue.main.async {
            var currentTime = Int(self.timeLabel.text!) ?? 0
            if currentTime != 0 {
                currentTime -= 1
                self.timeLabel.text = "\(currentTime)"
            }
            else {
                self.fiveSeconds()
            }
        }
    }
    
    public func initiateReRun() {
        
        didDetectBody = false
        left = 0
        right = 0
        normal = 0
        didRaiseHand = false
        labelTimer?.invalidate()
        
        timeLabel.text = "\(5)"
        messageLabel.text = "No Body Detected"
    }
    
    
}

extension HandDroppingController: ARSessionDelegate {
    
    public func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        for anchor in anchors {
            guard let bodyAnchor = anchor as? ARBodyAnchor else {
                //Invalidate Timer. Body is out of view
                if labelTimer?.isValid ?? false {
                    timeLabel.text = "\(5)"
                    labelTimer?.invalidate()
                }
                messageLabel.text = "No Body Detected."
                return
            }
            didDetectBody = true 
            
            let rightHandValue = abs((bodyAnchor.skeleton.modelTransform(for: .rightHand)?[0][0]) ?? 0.0)*100
            let leftHandValue = abs((bodyAnchor.skeleton.modelTransform(for: .leftHand)?[0][0]) ?? 0.0)*100
            
            
            if rightHandValue > 25.0 && leftHandValue > 25.0 {
                
                
                didRaiseHand = true
                //Both hands are up
                if labelTimer?.isValid ?? false {
                    
                }
                else {
                    setupTimerAndLabel()
                }
                
                DispatchQueue.main.async {
                    self.messageLabel.text = "Both hands are up"
                    self.normal += 1
                }
                
                
            }
                
            else if rightHandValue > 25.0 && leftHandValue < 25.0 {
                
                if didRaiseHand {
                    
                    DispatchQueue.main.async {
                        self.messageLabel.text = "Left hand has dropped"
                        self.left += 1
                        
                    }
                }
                else {
                    DispatchQueue.main.async {
                        self.messageLabel.text = "Please raise both hands and make the palms touch the ear"
                    }
                    return
                }
                
            }
                
            else if leftHandValue > 25.0  && rightHandValue < 25.0 {
                
                if didRaiseHand {
                    
                    DispatchQueue.main.async {
                        
                        self.messageLabel.text = "Right hand has dropped"
                        self.right += 1
                    }
                }
                else {
                    if didDetectBody {
                        
                        
                        DispatchQueue.main.async {
                            self.messageLabel.text = "Please raise both hands and make the palms touch the ears"
                        }
                        return
                    }
                }
                
            }
            else if leftHandValue < 25.0 && rightHandValue < 25.0{
                if didRaiseHand {
                    DispatchQueue.main.async {
                        self.messageLabel.text = "Both hands have dropped"
                        
                    }
                }
                    else {
                    DispatchQueue.main.async {
                            self.messageLabel.text = "Please raise both hands and make the palms touch the ears."
                            
                        }
                    
                }
            }
            
            
            
        }
    }
}
