//
//  QuizMainScreen.swift
//  SwiftUICharts
//
//  Created by Swapnanil Dhol on 5/16/20.
//  Copyright © 2020 Swapnanil Dhol. All rights reserved.
//

import SwiftUI

public struct QuizMainScreen: View {
    public init() {}
    private var questions: [String] = ["When does a stroke occur?", "Which among these is a symptom of stroke?", "What does F in FAST method of detection stand for?", "What percentage of stroke can be prevented by raising awareness?"]
    private var answers: [[String]] = [
        ["When blood flow to the brain is interrupted", "When you eat spoiled food", "When you drink a lot of soda"],
        ["Loving your new iPad Pro", "Being able to go out of your house", "Slurring Of Speech"],
        ["Food", "Fare", "Face"],
        ["80%", "10%", "Cannot be prevented even with adequate measures taken."]
    ]
    private var correctAnswerIndex: [Int] = [0, 2, 2, 0]
    @State private var score: Int = 0
    @State var isPresenting = false
    @State private var currentQuestion = 0
    @ObservedObject var audioModel = AudioModel()
    public var body: some View {
        VStack() {
            Text("Question: \(self.currentQuestion + 1)")
                .font(.system(size: 18, weight: .medium))
            .padding(.top,15)
                .multilineTextAlignment(.leading)
            
            Text(questions[currentQuestion])
                .bold()
                .multilineTextAlignment(.center)
                .font(.system(size: 28))
                .padding(40)
            
            Spacer()
            Button(action: {
                
                if self.correctAnswerIndex[self.currentQuestion] == 0 {
                    self.audioModel.playCorrectSound()
                    self.score += 1
                }
                else {
                    self.audioModel.playIncorrectSound()
                }
                
                if self.currentQuestion == 3 {
                    self.isPresenting = true
                    self.currentQuestion = 0
                    self.score = 0
                    return
                }
                self.currentQuestion += 1
            }) {
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(UIColor.systemPink))
                        .shadow(radius: 2)
                    Text(answers[currentQuestion][0])
                        .bold()
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.center)
                        .font(.system(size: 18))
                    
                }
                .frame(width: 320, height: 80)
            }
            Button(action: {
                if self.correctAnswerIndex[self.currentQuestion] == 1 {
                    self.audioModel.playCorrectSound()
                    self.score += 1
                }
                else {
                    self.audioModel.playIncorrectSound()
                }
                
                if self.currentQuestion == 3 {
                    self.isPresenting = true
                    self.currentQuestion = 0
                    self.score = 0
                    return
                    
                }
                self.currentQuestion += 1
            }) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(UIColor.systemBlue))
                        .shadow(radius: 2)
                    Text(answers[currentQuestion][1])
                        .foregroundColor(Color.white)
                        .bold()
                        .multilineTextAlignment(.center)
                        .font(.system(size: 18))
                }
                .frame(width: 320, height: 80)
            }
            Button(action: {
                if self.correctAnswerIndex[self.currentQuestion] == 2 {
                    self.audioModel.playCorrectSound()
                    self.score += 1
                }
                else {
                    self.audioModel.playIncorrectSound()
                }
                
                if self.currentQuestion == 3 {
                    self.isPresenting = true
                    self.currentQuestion = 0
                    self.score = 0
                    return
                    
                }
                self.currentQuestion += 1
            }) {
                ZStack(alignment: .center) {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(UIColor.systemGreen))
                        .shadow(radius: 2)
                    
                    Text(answers[currentQuestion][2])
                        .bold()
                        .multilineTextAlignment(.center)
                        .font(.system(size: 18))
                        .foregroundColor(Color.white)
                        .padding()
                    
                }
                .frame(width: 320, height: 80)
            }
            Spacer()
            Text("Your Score is: \(score)")
                .bold()
                .font(.system(size: 20))
            .padding(.bottom,15)
        }
        .sheet(isPresented: $isPresenting) {
            DetailView()
        }
        
    }
    
}



