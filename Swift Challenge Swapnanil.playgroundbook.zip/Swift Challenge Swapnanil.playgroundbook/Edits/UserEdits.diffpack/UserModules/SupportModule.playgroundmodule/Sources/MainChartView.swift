import SwiftUI

public struct MainChartsView: View {
    
    public init() {}
    
    @State public var dataPointsAmerica: [[CGFloat]] = [
        [120,100,80, 90, 75, 68],
        [100,110,80, 85, 73, 69],
        [100,89,100, 63, 53, 55],
        [80,110,90, 100, 70, 50]
    ]
    @State public var dataPointsIndia: [[CGFloat]] = [
        [145,122,105, 98, 72, 53],
        [133,120,110, 95, 73, 59],
        [140,118,105, 90, 80, 60],
        [100,89,100, 63, 53, 55]
    ]
    @State public var dataPointsUK: [[CGFloat]] = [
        [146,108,95, 90, 83, 68],
        [122,111,100,90, 85, 72],
        [100,89,100, 63, 53, 55],
        [80,110,90, 100, 70, 50]
    ]
    
    public var body: some View {
        
        ScrollView(.vertical, showsIndicators: true){
            VStack(alignment: .leading) {
                
                Text("🌏 Stroke Stats")
                    .font(.system(size: 34, weight: .bold, design: .default))
                    .padding(.all, 15)
                CapsuleChartsView(countryName: "India 🇮🇳", dataPoints: dataPointsIndia)
                    
                    .cornerRadius(12)
                    .padding()
                    .shadow(radius: 1)
                
                
                
                CapsuleChartsView(countryName: "USA 🇺🇸", dataPoints: dataPointsAmerica)
                    
                    .cornerRadius(12)
                    .padding()
                    .shadow(radius: 1)
                
                
                CapsuleChartsView(countryName: "UK 🇬🇧", dataPoints: dataPointsUK)
                    
                    .cornerRadius(12)
                    .padding()
                    .shadow(radius: 1)
                Text("Data sourced from aha journals and various govt facilities. Data may be inaccurate.")
                .multilineTextAlignment(.center)
                .padding()
                    .font(.footnote)
                
            }
            
        }
        
    }
}
