
//
//  CausesView.swift
//  SwiftUICharts
//
//  Created by Swapnanil Dhol on 5/16/20.
//  Copyright © 2020 Swapnanil Dhol. All rights reserved.
//

import SwiftUI

struct TypesView: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: true) {
            VStack(alignment: .center){
                ZStack {
                    Image(uiImage: UIImage(named: "doctor-illustration.png")!)
                        .resizable()
                    .frame(width: 250, height: 250)
                        .opacity(0.7)
                        .blur(radius: 5)
                        
                        .scaledToFit()
                    VStack {
                        Text("Types")
                            
                            .font(.system(size: 80, weight: .bold))
                            
                            .multilineTextAlignment(.center)
                        Text("From cdc.gov")
                            
                            .font(.system(size: 35, weight: .medium))
                            .padding(.bottom,10)
                            .multilineTextAlignment(.center)
                        
                    }
                }
                
                Text("Ischemic Stroke")
                    .font(.system(size: 25, weight: .bold))
                    .padding(.bottom, 10)
                Text("Most strokes (87%) are ischemic strokes. An ischemic stroke happens when blood flow through the artery that supplies oxygen-rich blood to the brain becomes blocked.Blood clots often cause the blockages that lead to ischemic strokes.")
                    .fontWeight(.medium)
                    .padding(.bottom, 16)
                
                Text("Hemorrhagic Stroke")
                    .font(.system(size: 25, weight: .bold))
                    .padding(.bottom, 10)
                Text("TA hemorrhagic stroke happens when an artery in the brain leaks blood or ruptures (breaks open). The leaked blood puts too much pressure on brain cells, which damages them. There are two types of hemorrhagic strokes: Intracerebral hemorrhage and Subarachnoid hemorrhage")
                    .fontWeight(.medium)
                    .padding(.bottom, 16)
            }
            .padding(.leading, 10)
            .padding(.trailing, 10)
            
        }
    }
}

struct TypesView_Previews: PreviewProvider {
    static var previews: some View {
        TypesView()
    }
}
