
//
//  SpeechAnalyzerController.swift
//  BodyDetection
//
//  Created by Swapnanil Dhol on 5/13/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import SoundAnalysis

public class SpeechAnalyzerController: UIViewController, ReRun {
    
    
    var timer: Timer?
    var labelTimer: Timer?
    let topStackView = UIStackView()
    var isListening = false
    private let audioEngine = AVAudioEngine()
    private var soundClassifier = SpeechDetector()
    var timeCount = 5
    
    var inputFormat: AVAudioFormat!
    var analyzer: SNAudioStreamAnalyzer!
    var resultsObserver = ResultsObserver()
    let analysisQueue = DispatchQueue(label: "com.custom.AnalysisQueue")
    var (slur, normal) = (0,0)
    
    
    let recordButton: UIButton = {
        
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .systemPurple
        return button
        
    }()
    
    let statusLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 22)
        label.text = "Tap Button to Begin"
        return label
    }()
    
    let timeRemainingLabel: UILabel = {
        
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont(name: "HelveticaNeue-Medium", size: 35)
        label.text = "5"
        return label
        
    }()
    
    let predictedOutputLabel: UILabel = {
        
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont(name: "HelveticaNeue-Medium", size: 25)
        label.text = "  Not Listening yet  "
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        label.clipsToBounds = true
        label.backgroundColor = .systemOrange
        return label
        
    }()
    
    let confidenceLabel: UILabel = {
        
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont(name: "HelveticaNeue", size: 20)
        label.textColor = .white
        label.text = "  100% Confident  "
        label.backgroundColor = .systemGreen
        label.clipsToBounds = true
        label.layer.cornerRadius = 4
        return label
        
    }()
    
    let bottomCardView: UIView = {
        let view = UIView()
        view.backgroundColor = .secondarySystemBackground
        view.layer.cornerRadius = 15
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    let trySayingThisLabel: UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .left
        lb.text = "Try Saying this"
        lb.alpha = 1.0
        lb.numberOfLines = 1
        lb.textColor = .secondaryLabel
        lb.font = UIFont(name: "HelveticaNeue", size: 16)
        return lb
    }()
    
    let speakThisLabel: UILabel = {
        let lb = UILabel()
        lb.textAlignment = .left
        lb.text = "Love is love cannot be killed or swept aside. Fill the world with music, love and pride."
        lb.alpha = 1.0
        lb.numberOfLines = 0
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.font = UIFont(name: "HelveticaNeue-Medium", size: 18)
        return lb
    }()
    
    let largeConfig = UIImage.SymbolConfiguration(pointSize: 60, weight: .medium, scale: .medium)
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .tertiarySystemBackground
        addButton()
        
        setupBottomCard()
        self.recordButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 70)
        resultsObserver.delegate = self
        inputFormat = audioEngine.inputNode.inputFormat(forBus: 0)
        analyzer = SNAudioStreamAnalyzer(format: inputFormat)
        
    }
    
    //MARK: Setup Views
    
    private func setupTopView() {
        
        //Status Label
        //speakThisLabel
        //Prompt Label
        
        view.addSubview(statusLabel)
        view.addSubview(trySayingThisLabel)
        view.addSubview(speakThisLabel)
        statusLabel.translatesAutoresizingMaskIntoConstraints = false 
        trySayingThisLabel.translatesAutoresizingMaskIntoConstraints = false 
        trySayingThisLabel.translatesAutoresizingMaskIntoConstraints = false 
        
        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 45),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            trySayingThisLabel.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 25),
            trySayingThisLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            trySayingThisLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            speakThisLabel.topAnchor.constraint(equalTo: trySayingThisLabel.bottomAnchor, constant: 10),
            speakThisLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            speakThisLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30)
            
        ])
        
    }
    
    private func addButton() {
        
        view.addSubview(recordButton)
        recordButton.tintColor = .white
        recordButton.setImage(UIImage(systemName: "mic", withConfiguration: largeConfig), for: .normal)
        NSLayoutConstraint.activate([
            
            recordButton.widthAnchor.constraint(equalToConstant: 160),
            recordButton.heightAnchor.constraint(equalToConstant: 160),
            recordButton.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
            recordButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 0)
        ])
        recordButton.layer.cornerRadius = 80
        recordButton.addTarget(self, action: #selector(recordButtonDidPress), for: .touchUpInside)
        setupTopView()
        
    }
    
    private func setupBottomCard() {
        
        view.addSubview(bottomCardView)
        
        NSLayoutConstraint.activate([
            
            bottomCardView.heightAnchor.constraint(equalToConstant: view.frame.height / 3 - 100),
            bottomCardView.widthAnchor.constraint(equalToConstant: view.frame.width),
            bottomCardView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 15),
            bottomCardView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomCardView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            
        ])
        shadowToView(view: bottomCardView)
        addBottomCardText()
        
    }
    
    
    
    private func shadowToView(view : UIView){
        view.layer.shadowOffset = CGSize(width: 0, height: 3)
        view.layer.shadowOpacity = 0.6
        view.layer.shadowRadius = 7.0
        view.layer.shadowColor = UIColor.darkGray.cgColor
    }
    
    @objc func recordButtonDidPress() {
        
        if !isListening {
            //Begin Listening
            recordButton.setImage(nil, for: .normal)
            
            recordButton.setTitle(String(self.timeCount), for: .normal)
            setupTimerAndLabel()
            statusLabel.text = "Listening..."
            isListening = true
            startAudioEngine()
            
        }
        else {
            recordButton.setTitle(nil, for: .normal)
            recordButton.setImage(UIImage(systemName: "mic", withConfiguration: largeConfig), for: .normal)
            
            labelTimer?.invalidate()
            self.timeCount = 5
            statusLabel.text = "Tap to begin..."
            predictedOutputLabel.text = "  Not Listening  "
            confidenceLabel.text = "  100% Confident  "
            isListening = false
            stopAudioEngine()
        }
        
    }
    
    private func addBottomCardText() {
        
        let bottomStackView = UIStackView()
        bottomCardView.addSubview(bottomStackView)
        bottomStackView.translatesAutoresizingMaskIntoConstraints = false
        bottomStackView.addArrangedSubview(predictedOutputLabel)
        predictedOutputLabel.layer.cornerRadius = 8
        bottomStackView.addArrangedSubview(confidenceLabel)
        bottomStackView.axis = .vertical
        bottomStackView.spacing = 4
        bottomStackView.alignment = .center
        NSLayoutConstraint.activate([
            bottomStackView.centerYAnchor.constraint(equalTo: bottomCardView.centerYAnchor, constant: -10),
            bottomStackView.centerXAnchor.constraint(equalTo: bottomCardView.centerXAnchor),
            bottomStackView.leadingAnchor.constraint(equalTo: bottomStackView.leadingAnchor, constant: 10),
            bottomStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10)
        ])
    }
    
    
    
    
    
    
    //MARK: Logic
    
    
    
    private func displayAnalysisController(with message: String, didDetectStroke: Bool) {
        
        let vc = AnalysisViewController()
        vc.message = message
        vc.didDetectStroke = didDetectStroke
        //vc.modalPresentationStyle = .fullScreen
        vc.delegate = self
        vc.isSpeechScreen = true
        labelTimer?.invalidate()
        
        DispatchQueue.main.async {
            self.present(vc, animated: true)
        }
    }
    
    private func setupTimerAndLabel() {
        
        labelTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateLabel), userInfo: nil, repeats: true)
    }
    
    @objc private func updateLabel() {
        
        
        DispatchQueue.main.async {
            
            if self.timeCount != 0 {
                self.timeCount -= 1
                self.recordButton.setTitle(String(self.timeCount), for: .normal)
            }
            else {
                self.processData()
            }
        }
    }
    
    
    
    private func processData() {
        stopAudioEngine()
        
        
        
        
        if normal > slur {
            //No Stroke Detected
            self.displayAnalysisController(with: "Your speech was analyzed to be Normal.\nHowever, if you're feel uneasy it's always a good idea to contact medical facilities ASAP", didDetectStroke: false)
            initiateReRun()
            
        }
        else {
            //Stroke Detected
            self.displayAnalysisController(with: "Slurred Speech was detected.\nThis could indicate a stroke.\nPlease contact medical facilities ASAP", didDetectStroke: true)
            initiateReRun()
            
        }
        
        
        
        
    }
    
}
extension SpeechAnalyzerController: SpeechClassiferDelegate {
    
    func displayPredictionResult(identifier: String, confidence: Double) {
        
        if identifier == "Normal" {normal += 1}
        else {slur += 1}
        
        DispatchQueue.main.async {
            self.predictedOutputLabel.text = "  \(identifier) Speech  "
            self.confidenceLabel.text = "  \(confidence.rounded()) %  "
        }
    }
    
    
    private func startAudioEngine() {
        
        do {
            let request = try SNClassifySoundRequest(mlModel: soundClassifier.model)
            try analyzer.add(request, withObserver: resultsObserver)
        } catch {
            print("Unable to prepare request: \(error.localizedDescription)")
            return
        }
        
        audioEngine.inputNode.installTap(onBus: 0, bufferSize: 8000, format: inputFormat) { buffer, time in
            self.analysisQueue.async {
                self.analyzer.analyze(buffer, atAudioFramePosition: time.sampleTime)
            }
        }
        
        do {
            
            try audioEngine.start()
        } catch( _){
            print("error in starting the Audio Engine")
        }
    }
    
    private func stopAudioEngine() {
        
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
    }
    
    public func initiateReRun() {
        stopAudioEngine()
        isListening = false
        recordButton.setImage(UIImage(systemName: "mic", withConfiguration: largeConfig), for: .normal)
        recordButton.setTitle(nil, for: .normal)
        timer?.invalidate()
        self.timeCount = 5
        normal = 0
        slur = 0
        predictedOutputLabel.text = "    Not Analyzing.   "
        confidenceLabel.text = "   100% Sure   "
        statusLabel.text = "Tap to begin..."
        isListening = false
        
    }
    
    
}

class ResultsObserver: NSObject, SNResultsObserving {
    var delegate: SpeechClassiferDelegate?
    func request(_ request: SNRequest, didProduce result: SNResult) {
        guard let result = result as? SNClassificationResult,
            let classification = result.classifications.first else { return }
        
        let confidence = classification.confidence * 100.0
        print(confidence, classification.identifier)
        if confidence > 65 {
            delegate?.displayPredictionResult(identifier: classification.identifier, confidence: confidence)
        }
    }
    
    
}

protocol SpeechClassiferDelegate {
    
    func displayPredictionResult(identifier: String, confidence: Double)
}
