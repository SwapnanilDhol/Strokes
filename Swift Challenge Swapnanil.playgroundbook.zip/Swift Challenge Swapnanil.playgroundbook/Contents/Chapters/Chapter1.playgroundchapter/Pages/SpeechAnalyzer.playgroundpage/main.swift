//#-hidden-code
import PlaygroundSupport
//#-end-hidden-code
//: # **Speech** Check 🗣
//: Run this page using the "Run My Code" Button.
//: This functionality uses the brand new CreateML's Sound Classification Option.

//: - Note: The ML model has been trained with limited datasets. Please try to slur your speech heavily to throw a positive stroke detected after analysis. Thank you

//: # Simulate a stroke
//:  ## Attempt to slur your speech during the analysis period.

//: [Tap here to go to the next page](@next)


//#-hidden-code
let vc = SpeechAnalyzerController()
PlaygroundPage.current.liveView = vc
//#-end-hidden-code


