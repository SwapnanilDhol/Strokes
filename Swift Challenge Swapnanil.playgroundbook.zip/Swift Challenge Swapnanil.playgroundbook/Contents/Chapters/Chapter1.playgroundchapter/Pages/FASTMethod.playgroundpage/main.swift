//:# F.A.S.T. Method of Stroke Detection

/*: What is the **F.A.S.T.** method?
 * F: When attempting to open mouth does one side of the **face** drop to a side?
 * A: When raising both arms does **one arm drift downwards**?
 * S: When attempting to speak a simple sentence does the **speech slur**?
 * T: If the answer to any of these questions is **yes** call emergency services immediately.
 */

//: - Note: Every page has a "Simulate Stroke section". Try those out to trigger a stroke alert.

//:## That's all for this page.

//: [Tap here to go to the next page](@next)
