//#-hidden-code
import PlaygroundSupport
//#-end-hidden-code
//: # **Arm** Drop Check 💪🏼
//: ## Raise both hands and if one arm drifts downwards then that could indicate a **Stroke**
//: Run this page using the "Run My Code" Button.

//: - Note: Bring both of your hand close to your ears. Your palms should be touching your ears and be facing outwards.

//: # Simulate a stroke
//:  ## After raising both hands drop one arm
//: This functionality uses the brand new **RealityKit** Framework to attach BodyAnchors and detect movements of particular joints.

//: [Tap here to go to the next page](@next)

//#-hidden-code
let vc = HandDroppingController()
PlaygroundPage.current.liveView = vc
//#-end-hidden-code


