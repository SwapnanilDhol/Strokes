//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
/*:
### Swift Challenge 2020 Submission
## A Swift Playground that aims to provide a proof of concept for using powerful technology to detect and raise awareness about Stroke. 🧠
*/

/*: Here are some quick facts about stroke.
 * Stroke kills nearly 150,000 of the 860,000 Americans who die of cardiovascular disease each year—that’s 1 in every 19 deaths from all causes.
 * A stroke causes brain tissue to die, which can lead to brain damage, disability, and death. This is disturbing because about 80% of strokes are preventable
 */

//: Yes, **80% of all strokes are preventable.** This requires awareness about the disease and methods to quickly detect if a person is at a risk of stroke. In the event of a stroke every second counts. This playground attempts to do just that.
//: Information from the CDC (US's Center for Disease Prevention and Control)

//: - Note: This page explains about the various types of strokes and their statistics around the world

//: [Tap here to go to the next page](@next)

PlaygroundPage.current.setLiveView(MainView())

//: **Credits**: Doctor Image from **drawkit.io**. Sounds from **freesound.org** and data sourced from various **government organizations**.











