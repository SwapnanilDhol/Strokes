//#-hidden-code
import PlaygroundSupport
//#-end-hidden-code
//: # **Face** Drop Check
//: ## Checking for the drop of face to a particular side could mean the opposite side of the brain is experiencing a stroke.

//: # Simulate a stroke
//:  ## After opening your mouth attempt to move your lower lips to either side and hold that position till the end of analysis (5 seconds).

//: [Tap here to go to the next page](@next)

//#-hidden-code
let faceDropController = FaceDropController()
PlaygroundPage.current.liveView = faceDropController
//#-end-hidden-code

