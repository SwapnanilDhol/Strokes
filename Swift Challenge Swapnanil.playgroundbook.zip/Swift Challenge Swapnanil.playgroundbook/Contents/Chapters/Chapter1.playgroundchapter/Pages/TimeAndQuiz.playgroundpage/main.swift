//#-hidden-code
import PlaygroundSupport
//#-end-hidden-code
//: # **Time**
//: If the analysis for any of the factors returned positive, it's a good time to contact your doctor. Remember, **80% of Stroke**, if treated at the right time can lead to full recovery.

//: # Run the Playground
//: To answer a simple 4 question quiz about what you've just learnt about the deadly yet recoverable effects of a stroke


//: This is the last page of this Playground Submission. Thank you for your time.

//#-hidden-code
PlaygroundPage.current.setLiveView(QuizMainScreen())
//#-end-hidden-code

