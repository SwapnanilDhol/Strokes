import SwiftUI


public struct CapsuleChartsView: View {

    
    @State public var pickerSelectedItem = 0
    public var countryName: String = "America 🇺🇸"
    @State public var dataPoints: [[CGFloat]] = [
        [50,100,150, 60, 20, 34],
        [150,100,50, 20, 20, 40],
        [10,20,30, 110, 20, 66],
        [50,100,150, 140, 20, 120]
    ]
    
    public var body: some View {
        
        ZStack {
            
            
            VStack {
                Text(countryName)
                    .font(.system(size: 26))
                    .fontWeight(.heavy)
                    .padding(.top, 10)
                    .foregroundColor(Color(UIColor.label))
                
                Picker(selection: $pickerSelectedItem, label: Text("Hello")) {
                    
                    Text("0-20").tag(0)
                    
                    Text("21-45").tag(1)
                    Text("45-70").tag(2)
                    
                }.pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal, 24)
                
                    HStack(spacing: 25) {
                        Text("In Millions")
                            .lineLimit(1)
                            .rotationEffect(.degrees(-90), anchor: .center)
                            .padding(.leading, 20)
                        BarView(value: dataPoints[pickerSelectedItem][0], range: "89-00")
                        BarView(value: dataPoints[pickerSelectedItem][1], range: "00-06")
                        BarView(value: dataPoints[pickerSelectedItem][2], range: "07-12")
                        BarView(value: dataPoints[pickerSelectedItem][3], range: "13-18")
                        BarView(value: dataPoints[pickerSelectedItem][4], range: "18-Now")
                        Spacer()
                        
                    }.padding(.top, 24)
                        .padding(.leading, -30)
                        .animation(.easeInOut)
                    
                
                Text("Range in Years")
                    .fontWeight(.medium)
                    .padding(.top, 10)
                    .padding(.bottom, 10)
                
            }
            
        }
        .background(Color(UIColor.systemGroupedBackground))
    }
    
}

