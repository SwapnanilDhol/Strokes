//
//  MainView.swift
//  SwiftUICharts
//
//  Created by Swapnanil Dhol on 5/16/20.
//  Copyright © 2020 Swapnanil Dhol. All rights reserved.
//

import SwiftUI

public struct MainView: View {
    @State private var isPresentingTypes = false
    @State private var isPresentingCauses = false
    @State private var isPresentingStats = false
    public var body: some View {
            VStack {
                
                Spacer()
                ZStack {
                    Image("doctor-illustration")
                    .resizable()
                        .opacity(0.7)
                    .blur(radius: 5)
                        
                    .scaledToFit()
                    Text("Strokes")
                        
                        .font(.system(size: 80, weight: .bold))
                        .padding(.bottom,10)
                        .multilineTextAlignment(.center)
                }
                    
                .frame(width: 380, height: 280, alignment: .top)
               
                Text("Tap on any of the buttons below to learn more")
                .padding()
                    .multilineTextAlignment(.center)
                .font(.system(size: 25, weight: .medium))
                    Spacer()
                Button(action: {
                    self.isPresentingTypes = true
                }) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .foregroundColor(Color(#colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1)))
                            
                            
                        Text("⓶ Types")
                            .foregroundColor(Color.white)
                            .font(.system(size: 25, weight: .heavy))
                    }
                }
                    .sheet(isPresented: $isPresentingTypes) {
                        TypesView()
                    }
                    
                .frame(width: 330, height: 70, alignment: .center)
                .padding(.top, 10)
                Button(action: {
                    self.isPresentingCauses = true
                }) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .foregroundColor(Color(#colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)))
                            
                        Text("🎗Causes")
                            .foregroundColor(Color.white)
                            .font(.system(size: 25, weight: .heavy))
                    }
                    
                }
                    .sheet(isPresented: $isPresentingCauses) {
                        CausesView()
                    }
                
                    
                .frame(width: 330, height: 70, alignment: .center)
                .padding(.top, 10)
               
                
                Button(action: {
                    self.isPresentingStats = true
                }) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .foregroundColor(Color(#colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)))
                            
                        Text("🌍 Statistics")
                            .foregroundColor(Color.white)
                            .font(.system(size: 25, weight: .heavy))
                    }
                }
                    .frame(width: 330, height: 70, alignment: .center)
                .padding(.top, 10)
                .padding(.bottom, 10)
                    .sheet(isPresented: $isPresentingStats) {
                        MainChartsView()
                    }
                
                .foregroundColor(Color(UIColor.systemBackground))
                
            }
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
            .environment(\.colorScheme, .dark)
    }
}
