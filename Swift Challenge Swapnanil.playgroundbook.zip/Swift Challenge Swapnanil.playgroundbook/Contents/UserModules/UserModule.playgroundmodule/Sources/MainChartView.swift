import SwiftUI

public struct MainChartsView: View {
    
    public init() {} 
    
    public var body: some View {
        
            ScrollView(.vertical, showsIndicators: true){
                VStack(alignment: .leading) {
                    
                    Text("🌏 Stroke Stats")
                        .font(.system(size: 34, weight: .bold, design: .default))
                        .padding(.all, 15)
                    CapsuleChartsView(countryName: "India 🇮🇳")
                        
                        .cornerRadius(12)
                        .padding()
                        .shadow(radius: 1)
                    
                    
                    
                    CapsuleChartsView(countryName: "USA 🇺🇸")
                        
                        .cornerRadius(12)
                        .padding()
                        .shadow(radius: 1)
                    
                    
                    CapsuleChartsView(countryName: "London 🇬🇧")
                        
                        .cornerRadius(12)
                        .padding()
                        .shadow(radius: 1)
                    
                }
            
        }
        
    }
}
