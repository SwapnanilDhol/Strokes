//
//  CausesView.swift
//  SwiftUICharts
//
//  Created by Swapnanil Dhol on 5/16/20.
//  Copyright © 2020 Swapnanil Dhol. All rights reserved.
//

import SwiftUI

struct CausesView: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: true) {
            VStack(alignment: .leading){
                ZStack {
                    Image("doctor-colour-800px")
                    .resizable()
                        .opacity(0.9)
                    .blur(radius: 5)
                        
                    .scaledToFit()
                    VStack {
                        Text("Causes")
                            
                            .font(.system(size: 80, weight: .bold))
                            
                            .multilineTextAlignment(.center)
                        Text("From webmd.com")
                        
                        .font(.system(size: 35, weight: .medium))
                        .padding(.bottom,10)
                        .multilineTextAlignment(.center)

                    }
                }
                
                Text("High Blood Pressure")
                    .font(.system(size: 25, weight: .bold))
                    .padding(.bottom, 10)
                Text("Your doctor may call it hypertension. It's the biggest cause of strokes. If your blood pressure is typically 140/90 there is a high risk of a stroke.")
                    .fontWeight(.medium)
                    .padding(.bottom, 16)
                        
                Text("Heart Disease")
                    .font(.system(size: 25, weight: .bold))
                    .padding(.bottom, 10)
                Text("This condition includes defective heart valves as well as atrial fibrillation, or irregular heartbeat, which causes a quarter of all strokes among the very elderly. You can also have clogged arteries from fatty deposits.")
                    .fontWeight(.medium)
                    .padding(.bottom, 16)
                Text("Diabetes")
                    .font(.system(size: 25, weight: .bold))
                    .padding(.bottom, 10)
                Text("People who have it often have high blood pressure and are more likely to be overweight. Both raise the chance of a stroke. Diabetes damages your blood vessels, which makes a stroke more likely.")
                    .fontWeight(.medium)
                    .padding(.bottom, 16)
            }
            .padding(.leading, 10)
            .padding(.trailing, 10)
            
        }
    }
}

struct CausesView_Previews: PreviewProvider {
    static var previews: some View {
        CausesView()
    }
}
