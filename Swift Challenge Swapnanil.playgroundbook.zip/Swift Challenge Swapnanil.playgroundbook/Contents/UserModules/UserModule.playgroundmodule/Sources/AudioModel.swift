import Combine
import SwiftUI
import AVKit
import UIKit



class AudioModel: ObservableObject {
    
    var audioPlayer: AVAudioPlayer?

    @Published var current: String = ""

    var audioFiles = ["successSound.wav", "failSound.wav"]

    func playCorrectSound() {

        let path = Bundle.main.path(forResource: audioFiles[0], ofType:nil)!
        let url = URL(fileURLWithPath: path)

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch {
            print("Could not find file")

        }
    }
    
    func playIncorrectSound() {

        let path = Bundle.main.path(forResource: audioFiles[1], ofType:nil)!
        let url = URL(fileURLWithPath: path)

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch {
            print("Could not find file")

        }
    }

    func stopSound() {
        
    }
}

