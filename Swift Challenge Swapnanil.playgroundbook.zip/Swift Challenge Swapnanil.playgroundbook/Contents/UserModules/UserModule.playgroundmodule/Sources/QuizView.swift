//
//  QuizMainScreen.swift
//  SwiftUICharts
//
//  Created by Swapnanil Dhol on 5/16/20.
//  Copyright © 2020 Swapnanil Dhol. All rights reserved.
//

import SwiftUI

public struct QuizMainScreen: View {
    private var questions: [String] = ["When does a stroke occur?", "Which among these is a symptom of stroke?", "What does F in FAST method of detection stand for?", "What percentage of stroke can be prevented by raising awareness?"]
    private var answers: [[String]] = [
        ["When blood flow to the brain is interrupted", "When you eat spoiled food", "When you forget your mom’s birthday"],
        ["Loving your new iPad Pro", "Being able to go out of your house", "Slurring Of Speech"],
        ["Food", "Fare", "Face"],
        ["80%", "10%", "Cannot be prevented even with adequate measures taken."]
    ]
    public init() {}
    private var correctAnswerIndex: [Int] = [0, 2, 2, 1]
    @State private var score: Int = 0
    @State var isPresenting = false
    @State private var currentQuestion = 0
    @ObservedObject var audioModel = AudioModel()
    public var body: some View {
        VStack() {
            Text("Question: \(self.currentQuestion + 1)")
                .font(.system(size: 18, weight: .medium))
                .multilineTextAlignment(.leading)
                .padding(.top, 40)
            Text(questions[currentQuestion])
                .bold()
                .multilineTextAlignment(.center)
                .font(.system(size: 28))
                .padding(.leading, 25)
                .padding(.trailing, 25)
                .padding(.bottom, 35)
            
            Spacer()
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color(UIColor.systemPink))
                    .shadow(radius: 2)
                Text(answers[currentQuestion][0])
                    .bold()
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.center)
                    .font(.system(size: 18))
                
            }
            .frame(width: 320, height: 80)
            .onTapGesture {
                
                if self.correctAnswerIndex[self.currentQuestion] == 0 {
                    self.audioModel.playCorrectSound()
                    self.score += 1
                }
                else {
                    self.audioModel.playIncorrectSound()
                }
                
                if self.currentQuestion == 2 {
                    self.isPresenting = true
                    self.currentQuestion = 0
                    self.score = 0
                     
                }
                self.currentQuestion += 1
            }
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color(UIColor.systemBlue))
                    .shadow(radius: 2)
                Text(answers[currentQuestion][1])
                    .foregroundColor(Color.white)
                    .bold()
                    .multilineTextAlignment(.center)
                    .font(.system(size: 18))
            }
            .frame(width: 320, height: 80)
            .onTapGesture {
                if self.correctAnswerIndex[self.currentQuestion] == 1 {
                    self.audioModel.playCorrectSound()
                    self.score += 1
                }
                else {
                    self.audioModel.playIncorrectSound()
                }
                
                if self.currentQuestion == 2 {
                    self.isPresenting = true
                    self.currentQuestion = 0
                    self.score = 0
                     
                }
                self.currentQuestion += 1
                
            }
            
            ZStack(alignment: .center) {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color(UIColor.systemGreen))
                    .shadow(radius: 2)
                    
                Text(answers[currentQuestion][2])
                    .bold()
                    .multilineTextAlignment(.center)
                    .font(.system(size: 18))
                    .foregroundColor(Color.white)
                .padding()
                
            }
            .frame(width: 320, height: 80)
            .onTapGesture {
                if self.correctAnswerIndex[self.currentQuestion] == 2 {
                    self.audioModel.playCorrectSound()
                    self.score += 1
                }
                else {
                    self.audioModel.playIncorrectSound()
                }
                
                if self.currentQuestion == 2 {
                    self.isPresenting = true
                    self.currentQuestion = 0
                    self.score = 0
                     
                }
                self.currentQuestion += 1
            }
            
            Spacer()
            Text("Your Score is: \(score)")
                .bold()
                .font(.system(size: 20))
            .padding()
        }
        .sheet(isPresented: $isPresenting) {
            DetailView()
        }
        
    }
    
}
