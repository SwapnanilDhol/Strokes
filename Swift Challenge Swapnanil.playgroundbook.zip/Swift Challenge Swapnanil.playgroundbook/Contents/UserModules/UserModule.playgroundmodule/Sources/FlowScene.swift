
import SpriteKit

public enum CollisionType: UInt32 {
    
    case bloodCells = 1
    case arteries = 2
    
}

public class FlowScene: SKScene {

    let arteriesLeft = SKSpriteNode(imageNamed: "Left")
    let arteriesRight = SKSpriteNode(imageNamed: "Right")
    let path = UIBezierPath()
    var viewController : FlowViewController!
    
    let arteriesRect = CGRect()
    
    public override func didMove(to view: SKView) {
        
        self.backgroundColor = .systemRed
        if let bloodCells = SKEmitterNode(fileNamed: "RBC") {
            bloodCells.position = CGPoint(x: self.frame.width / 2, y: self.frame.height)
            bloodCells.advanceSimulationTime(40)
            bloodCells.particleZPosition = -1
            bloodCells.physicsBody?.categoryBitMask = CollisionType.bloodCells.rawValue
            bloodCells.physicsBody?.collisionBitMask = CollisionType.arteries.rawValue
            bloodCells.physicsBody?.contactTestBitMask = CollisionType.arteries.rawValue
            addChild(bloodCells)
        }
        
        arteriesLeft.name = "Arteries"
        arteriesLeft.position.x = self.frame.midX - 305
        arteriesLeft.position.y = self.frame.height / 2
        
        addChild(arteriesLeft)
        
        arteriesRight.name = "Arteries"
        arteriesRight.position.x = self.frame.midX + 305
        arteriesRight.position.y = self.frame.height / 2
        addChild(arteriesRight)
        
        //arteriesLeft.size = CGSize(width: 300, height: self.frame.height)
        
        
        arteriesLeft.zPosition = 1
        arteriesRight.zPosition = 1
        
        arteriesLeft.physicsBody = SKPhysicsBody(rectangleOf: arteriesLeft.size)
        arteriesRight.physicsBody = SKPhysicsBody(rectangleOf: arteriesRight.size)
        
        arteriesLeft.physicsBody?.categoryBitMask = CollisionType.arteries.rawValue
        arteriesRight.physicsBody?.categoryBitMask = CollisionType.arteries.rawValue
        arteriesLeft.physicsBody?.collisionBitMask = CollisionType.bloodCells.rawValue
        arteriesLeft.physicsBody?.contactTestBitMask = CollisionType.bloodCells.rawValue
        arteriesLeft.physicsBody?.isDynamic = false
        arteriesRight.physicsBody?.collisionBitMask = CollisionType.bloodCells.rawValue
        arteriesRight.physicsBody?.contactTestBitMask = CollisionType.bloodCells.rawValue
        arteriesRight.physicsBody?.isDynamic = false
    }
    
    

}

extension UIBezierPath
{

    func move(path: UIBezierPath, fromPoint: CGPoint, toPoint: CGPoint) {
        let moveX = toPoint.x - fromPoint.x
        let moveY = toPoint.y - fromPoint.y
        path.apply(CGAffineTransform(translationX: moveX, y: moveY))
    }

    func scale(path: UIBezierPath, fromSize: CGSize, toSize: CGSize) {
        if fromSize.width == 0 || fromSize.height == 0 {
            return
        }
        let scaleWidth = toSize.width / fromSize.width
        let scaleHeight = toSize.height / fromSize.height
        path.apply(CGAffineTransform(scaleX: scaleWidth, y: scaleHeight))
    }

}


