import SwiftUI

public struct BarView: View {
    
  public var value: CGFloat = 0
  public var range: String = ""
    
    public var body: some View {
        
        VStack {
            ZStack(alignment: .bottom) {
                Capsule().frame(width: 30, height: 150)
                    .foregroundColor(Color(UIColor.secondarySystemFill))
                Capsule().frame(width: 30, height: value)
                    .foregroundColor(Color(UIColor.label))
            }
            Text(range)
                .fontWeight(.medium)
                .font(.system(size: 15))
                .foregroundColor(Color(UIColor.label))
            
        }
        
    }
}

