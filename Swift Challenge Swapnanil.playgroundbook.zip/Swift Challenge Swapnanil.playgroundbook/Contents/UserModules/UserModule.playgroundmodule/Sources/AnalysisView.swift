import UIKit
import AVFoundation

public protocol ReRun {
    
    func initiateReRun()
}

public class AnalysisViewController: UIViewController {
    var player: AVAudioPlayer?
    public var message = String()
    public var didDetectStroke = Bool()
    public var isSpeechScreen = false
    let stackView = UIStackView()
    let dismissButton: UIButton = {
        let button = UIButton()
        button.setTitle("      Re-Run      ", for: .normal)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.isUserInteractionEnabled = true
        return button
    }()
    
    let analysisCompletedLabel: UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 0
        lb.textColor = .label
        lb.font = UIFont(name: "HelveticaNeue-Bold", size: 30)
        return lb
    }()
    
    let messageLabel: UILabel = {
        let lb = UILabel()
        lb.translatesAutoresizingMaskIntoConstraints = false
        lb.textAlignment = .center
        lb.numberOfLines = 0
        lb.textColor = .label
        lb.font = UIFont(name: "HelveticaNeue-Medium", size: 18)
        return lb
    }()
    
    let tickImageView = UIImageView()
    public var delegate: ReRun?
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .secondarySystemBackground
        if !isSpeechScreen {
            if didDetectStroke {
                playFailSound()
            }
            else {
                playSuccessSound()
            }
        }
        setupView()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        player?.stop()
    }
    
    
    
    
    private func setupView() {
        let largeConfig = UIImage.SymbolConfiguration(pointSize: 100, weight: .bold, scale: .large)
        let tickImage = didDetectStroke ? UIImage(systemName: "exclamationmark.triangle.fill", withConfiguration: largeConfig) : UIImage(systemName: "checkmark", withConfiguration: largeConfig)
        tickImageView.image = tickImage
        tickImageView.tintColor = didDetectStroke ? .systemYellow : .systemGreen
        dismissButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
        dismissButton.addTarget(self, action: #selector(rerunButtonDidTap), for: .touchUpInside)
        tickImageView.translatesAutoresizingMaskIntoConstraints = false
        analysisCompletedLabel.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 15
        stackView.addArrangedSubview(tickImageView)
        
        stackView.addArrangedSubview(analysisCompletedLabel)
        stackView.addArrangedSubview(messageLabel)
        stackView.addArrangedSubview(dismissButton)
        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),
            stackView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10)
        ])
        if didDetectStroke {
            analysisCompletedLabel.text = "Analysis Completed.\nStroke symptoms detected!!"
        }
        else {
            analysisCompletedLabel.text = "Analysis Completed.\nStroke symptoms not detected."
        }
        messageLabel.text = message
        
    }
    
    //Button Actions
    
    @objc private func rerunButtonDidTap() {
        
        delegate?.initiateReRun()
        self.dismiss(animated: true)
    }
    
    func playSuccessSound() {
        guard let url = Bundle.main.url(forResource: "successSound", withExtension: "wav") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func playFailSound() {
        guard let url = Bundle.main.url(forResource: "failSound", withExtension: "wav") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
}

