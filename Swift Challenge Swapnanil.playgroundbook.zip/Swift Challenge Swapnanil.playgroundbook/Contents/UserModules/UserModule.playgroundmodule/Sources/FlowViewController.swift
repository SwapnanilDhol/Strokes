import UIKit
import SpriteKit

public class FlowViewController: UIViewController {

    var skView: SKView!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setupGameScene()
    }

    func setupGameScene() {
        let widthOfParent = self.view.frame.width
        let heightOfParent = self.view.frame.height
        self.view = SKView()
        let skView = self.view as! SKView
            
        let scene = FlowScene(size: CGSize(width: widthOfParent, height: heightOfParent))
        
        if let flowScene = scene as? FlowScene {
            
            flowScene.viewController = self
        }
            scene.scaleMode = .aspectFill
            skView.presentScene(scene)
            skView.ignoresSiblingOrder = true
    }
    
}
